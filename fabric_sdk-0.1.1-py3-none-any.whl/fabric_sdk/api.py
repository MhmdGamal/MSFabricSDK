from sempy.fabric import list_workspaces ,list_items ,list_dataflows
from urllib.parse import urljoin
import pandas as pd
import requests
class FabricAPIBase:
    def __init__(self, base_url=None, token=None):
        self.base_url = base_url or "https://api.fabric.microsoft.com/v1/"
        if token:
            self.token = token
        else:
            try:
                # Import notebookutils only if available
                from notebookutils.credentials import getToken
                self.token = getToken('pbi')
            except ImportError:
                raise ImportError(
                    "notebookutils is not available. Please provide a token manually when initializing FabricAPIBase."
                )
    def make_request(self, method='GET', endpoint=None, params=None, data=None,max_retries=5):
        
        
        url = urljoin(self.base_url, endpoint)
        headers = {
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        }

 
        response = requests.request(
            method,
            url,
            headers=headers,
            params=params,
            data=json.dumps(data) if data else None
        )
        response.raise_for_status()
        return response.json()
    def GetAllWorkspaces(self):
        self.workspaces = list_workspaces()
        self.workspaces['Git_status']=[ self.make_request('GET',f'workspaces/{id}/git/connection')['gitConnectionState'] for id in self.workspaces['Id']]
        return self.workspaces #dataframe
    def GetFabricWorkspaces(self):
        self.workspaces = list_workspaces()
        self.workspaces['Git_status']=[ self.make_request('GET',f'workspaces/{id}/git/connection')['gitConnectionState'] for id in self.workspaces['Id']]
        self.fabric_workspaces_IDs=[]
        for id in self.workspaces['Id']:
            if (('Lakehouse' in set(list_items(workspace=id)['Type'].values)) or 
                ('DataPipeline' in set(list_items(workspace=id)['Type'].values)) or 
                ('Warehouse' in set(list_items(workspace=id)['Type'].values)) or 
                ('Notebook' in set(list_items(workspace=id)['Type'].values)) or
                (list_dataflows(id).shape[0] > 0)):
                   self.fabric_workspaces_IDs.append(id)
        self.fabric_workspaces=self.workspaces[self.workspaces['Id'].isin(self.fabric_workspaces_IDs)]
        return self.fabric_workspaces
    def GetPowerBIWorkspaces(self):
        self.workspaces = list_workspaces()
        self.workspaces['Git_status']=[ self.make_request('GET',f'workspaces/{id}/git/connection')['gitConnectionState'] for id in self.workspaces['Id']]
        self.PowerBI_workspaces_IDs=[]
        for id in self.workspaces['Id']:
            if not (('Lakehouse' in set(list_items(workspace=id)['Type'].values)) or 
                ('DataPipeline' in set(list_items(workspace=id)['Type'].values)) or 
                ('Warehouse' in set(list_items(workspace=id)['Type'].values)) or 
                ('Notebook' in set(list_items(workspace=id)['Type'].values)) or
                (list_dataflows(id).shape[0] > 0)):
                   self.PowerBI_workspaces_IDs.append(id)
        self.PowerBI_workspaces=self.workspaces[self.workspaces['Id'].isin(self.PowerBI_workspaces_IDs)]
        return self.PowerBI_workspaces
    def GetAllWarehouses(self):
        return list_items('Warehouse')
    def GetAllLakehouses(self):
        return list_items('Lakehouse')
    def GetWarehouseByID(self,ID):
        self.warehouses=list_items('Warehouse')
        return self.warehouses[self.warehouses['Id']==ID]
    def GetWarehouseByName(self,Name):
        self.warehouses=list_items('Warehouse')
        return self.warehouses[self.warehouses['Display Name']==Name]
    def GetLakehouseByID(self,ID):
        self.Lakehouses=list_items('Lakehouse')
        return self.Lakehouses[self.Lakehouses['Id']==ID]
    def GetLakehouseByName(self,Name):
        self.Lakehouses=list_items('Lakehouse')
        return self.Lakehouses[self.Lakehouses['Display Name']==Name]

    # def GetDataPipelines(self,workspaceId):
    #     #return self.make_request('GET',f'workspaces/{workspaceId}/items')
    #     return list_items(workspace=workspaceId)
    # def GetPipelinesRunStatus(self,workspace_id,pipeline_id):
    #     #workspaces/{workspaceId}/items/{itemId}/jobs/instances
    #     return self.make_request('GET',f'workspaces/{workspace_id}/items/{pipeline_id}/jobs/instances')

    def FetchDataPipelines(self, workspace_id):
        try:
            items = list_items(workspace=workspace_id)  # Assuming this returns a DataFrame
            pipelines = items[items['Type'] == 'DataPipeline']

            if not pipelines.empty:
                # Return the matching pipelines as a DataFrame
                return pipelines
            else:
                # Return an empty DataFrame with columns matching the items schema
                return pd.DataFrame(columns=items.columns)
        except Exception as e:
            # Returning an error as a DataFrame for consistency
            return pd.DataFrame({"error": [f"Failed to fetch data pipelines: {str(e)}"]})

    def FetchPipelineRunDetails(self, workspace_id, pipeline_id):
        try:
            endpoint = f'workspaces/{workspace_id}/items/{pipeline_id}/jobs/instances'
            response = self.make_request('GET', endpoint)

            if 'value' in response:
                # Convert the response['value'] list of dictionaries to a DataFrame
                runs_df = pd.DataFrame(response['value'])

                # Return the DataFrame
                if not runs_df.empty:
                    return runs_df
                else:
                    # Return an empty DataFrame with predefined columns
                    return pd.DataFrame(columns=["id", "status", "startTime", "endTime", "triggeredBy", "failureReason"])
            else:
                return pd.DataFrame({"message": ["No runs found for the pipeline"]})
        except Exception as e:
            return pd.DataFrame({"error": [f"Failed to fetch pipeline run details: {str(e)}"]})

    
    def GetPipelineDetailsByName(self, pipeline_name):
        try:
            workspaces = list_workspaces()  # Fetch all workspaces
            if workspaces is None or workspaces.empty:
                return {"error": "No workspaces found"}

            # Iterate over all workspaces
            for workspace_id in workspaces['Id']:
                items = list_items(workspace=workspace_id)  # Fetch items in the workspace

                if items is None or items.empty:
                    continue

                # Filter items for Data Pipelines
                pipelines = items[items['Type'] == 'DataPipeline']

                if pipelines.empty:
                    continue

                # Match pipeline by name
                matching_pipeline = pipelines[pipelines['Display Name'] == pipeline_name]

                if not matching_pipeline.empty:
                    # Retrieve pipeline details as a dictionary
                    pipeline_details = matching_pipeline.iloc[0].to_dict()
                    pipeline_details["Workspace Id"] = workspace_id

                    # Return details as a DataFrame for consistency
                    return pd.DataFrame([pipeline_details])

            # If no matching pipeline is found
            return pd.DataFrame({"error": [f"No pipeline found with name '{pipeline_name}' in any workspace"]})
        except Exception as e:
            # Return an error message as a DataFrame
            return pd.DataFrame({"error": [f"Failed to fetch pipeline details: {str(e)}"]})

    def GetPipelineAllRunsStatuses(self, workspace_name, pipeline_name):
        try:
            workspaces = list_workspaces()

            # Validate workspace existence
            matching_workspace = workspaces[workspaces['Name'] == workspace_name]
            if matching_workspace.empty:
                return pd.DataFrame({"error": [f"No workspace found with name '{workspace_name}'"]})

            workspace_id = matching_workspace.iloc[0]['Id']
            items = list_items(workspace=workspace_id)

            # Validate pipeline existence
            pipelines = items[items['Type'] == 'DataPipeline']
            matching_pipeline = pipelines[pipelines['Display Name'] == pipeline_name]
            if matching_pipeline.empty:
                return pd.DataFrame({"error": [f"No pipeline found with name '{pipeline_name}' in workspace '{workspace_name}'"]})

            pipeline_id = matching_pipeline.iloc[0]['Id']
            endpoint = f"workspaces/{workspace_id}/items/{pipeline_id}/jobs/instances"
            response = self.make_request('GET', endpoint)

            if 'value' in response:
                runs = response['value']
                if runs:
                    # Return runs as a DataFrame
                    return pd.DataFrame(runs)
                else:
                    # Return an empty DataFrame if no runs
                    return pd.DataFrame({"message": ["No runs found for this pipeline"]})
            else:
                return pd.DataFrame({"error": [f"No runs found for pipeline '{pipeline_name}'"]})
        except Exception as e:
            return pd.DataFrame({"error": [f"Failed to fetch pipeline run statuses: {str(e)}"]})

    def GetPipelineLastRunStatus(self, workspace_name, pipeline_name):
        try:
            workspaces = list_workspaces()

            # Validate workspace existence
            matching_workspace = workspaces[workspaces['Name'] == workspace_name]
            if matching_workspace.empty:
                return pd.DataFrame({"error": [f"No workspace found with name '{workspace_name}'"]})

            workspace_id = matching_workspace.iloc[0]['Id']
            items = list_items(workspace=workspace_id)

            # Validate pipeline existence
            pipelines = items[items['Type'] == 'DataPipeline']
            matching_pipeline = pipelines[pipelines['Display Name'] == pipeline_name]
            if matching_pipeline.empty:
                return pd.DataFrame({"error": [f"No pipeline found with name '{pipeline_name}' in workspace '{workspace_name}'"]})

            pipeline_id = matching_pipeline.iloc[0]['Id']
            endpoint = f"workspaces/{workspace_id}/items/{pipeline_id}/jobs/instances"
            response = self.make_request('GET', endpoint)

            # Ensure the response contains valid run data
            if 'value' in response and response['value']:
                # Extract runs and ensure valid 'startTimeUtc' is present
                runs = response['value']
                runs_with_start_time = [run for run in runs if 'startTimeUtc' in run]
                if not runs_with_start_time:
                    return pd.DataFrame({"error": ["No runs with valid 'startTimeUtc' found."]})

                # Sort runs by 'startTimeUtc' in descending order
                sorted_runs = sorted(runs_with_start_time, key=lambda x: x['startTimeUtc'], reverse=True)
                last_run = sorted_runs[0]  # Get the most recent run

                # Convert the last run to a DataFrame
                return pd.DataFrame([last_run])
            else:
                # Handle case where no runs are found
                return pd.DataFrame({"error": [f"No runs found for pipeline '{pipeline_name}' in workspace '{workspace_name}'"]})
        except Exception as e:
            # Handle exceptions and return as a DataFrame
            return pd.DataFrame({"error": [f"Failed to fetch last run status: {str(e)}"]})
    def GetWorkspaceRoleAssignments(self, workspace_id):
        """Get role assignments for a specific workspace """
        try:
            response = self.make_request('GET', f'workspaces/{workspace_id}/roleAssignments')
            role_assignments = response.get('value', [])
            
            if role_assignments:

                df = pd.json_normalize(role_assignments, 
                                       sep='_',  
                                       record_path=None, 
                                       meta=['id', 'role'], 
                                       meta_prefix='role_',
                                       record_prefix='principal_')
                
                if 'principal_userDetails' in df.columns:
                    user_details_df = pd.json_normalize(df['principal_userDetails'])
                    user_details_df.columns = [f'principal_userDetails_{col}' for col in user_details_df.columns]
                    df = pd.concat([df.drop(columns=['principal_userDetails']), user_details_df], axis=1)
                
                return df
            else:
                return pd.DataFrame()  
        except requests.exceptions.RequestException as e:
            print(f"Error retrieving role assignments for workspace {workspace_id}: {e}")
            return pd.DataFrame()  
    

   